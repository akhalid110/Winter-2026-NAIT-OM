// CMPE 2000 - Fall2025 Lab Exam5 

//Global Variable to store cost of selected food item.
let foodCost = 15;
let birdArray = ["bird1.jfif", "eagle.jpg", "flamingo.jpeg", "kingfisher.jpg", "parot.jpg"]
let count = 0;

window.onload = () => {

    document.querySelector("input[name=uname]").onchange = validate;
    document.form["form"].onsubmit=validate;
    document.querySelectorAll("input[name=food]").forEach(r=>{r.onchange=validate});
    document.querySelector("#firstBird").onclick= DisplayPic;
    
}
function UpdateName(){
    
  
    
}

function validate() {
    ``
    let name = document.querySelector("input[name=uname]").value;
    //name=Number(this.value);
    if(name===" "){
        alert("Name textbox do not be empty.")
    }
    let food = document.querySelector("input[name=food]:checked");
    let foodvalue= Number(food.value);
    let totalcost= 0;
     switch(food){
        case "burger" : if(foodvalue=5) totalcost+foodvalue ;
        case "sandwich": if(foodvalue = 6) totalcost+foodvalue;
        case "pizza": if(foodvalue= 9) totalcost+foodvalue;
        break;
     }
    return false;
}

function DisplayPic(){
    let pic = document.querySelector("#firstBird");

}


